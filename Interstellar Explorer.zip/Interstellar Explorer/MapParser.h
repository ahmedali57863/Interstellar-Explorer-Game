#pragma once
#ifndef MAPPARSER_H
#define MAPPARSER_H

#include <map>
#include <string>
#include "GameMap.h"
#include "TinyXML/tinyxml.h"
#include "TileLayer.h"
using namespace std;

class MapParser
{
private:
    MapParser() {}
    bool Parse(string id, string source);
    Tileset ParseTileset(TiXmlElement* xmlTileset);
    TileLayer* ParseTileLayer(TiXmlElement* xmlLayer, vector<Tileset> tilesets, int tilesize, int rowcount, int colcount);

    static MapParser* s_Instance;
    map<string, GameMap*> m_MapDict;

public:
    bool Load();
    void Clean();

    inline GameMap* GetMap(string id) { return m_MapDict[id]; }
    inline static MapParser* GetInstance()
    {
        if (s_Instance != nullptr)
        {
            return s_Instance;
        }
        else 
        {
            s_Instance = new MapParser();
            return s_Instance;
        }
    }

};

#endif // MAPPARSER_H
