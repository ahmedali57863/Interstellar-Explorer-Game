#pragma once
#ifndef TIMER_H
#define TIMER_H

const int TARGET_FPS = 60;
const float TARGET_DELTATIME = 1.5f;

using namespace std;

class Timer 
{
private:
    Timer() {}
    static Timer* s_Instance;
    float m_DeltaTime;
    float m_LastTime;

public:
    void Tick();
    inline float GetDeltaTime() { return m_DeltaTime; }

    inline static Timer* GetInstance() 
    {
        if (s_Instance != nullptr) 
        {
            return s_Instance;
        }
        else 
        {
            s_Instance = new Timer();
            return s_Instance;
        }
    }
};

#endif // TIMER_H


