#pragma once
#ifndef COLLISIONHANDLER_H
#define COLLISIONHANDLER_H

#include "SDL.h"
#include <vector>
#include "TileLayer.h"
#include "GameMap.h"
using namespace std;

class CollisionHandler 
{
private:
    CollisionHandler();
    TileMap m_CollisionTilemap;
    TileLayer* m_CollisionLayer;
    static CollisionHandler* s_Instance;

public:
    bool MapCollision(SDL_Rect a);
    bool CheckCollision(SDL_Rect a, SDL_Rect b);

    inline static CollisionHandler* GetInstance() {
        if (s_Instance != nullptr) 
        {
            return s_Instance;
        }
        else 
        {
            s_Instance = new CollisionHandler();
            return s_Instance;
        }
    }

};

#endif // COLLISIONHANDLER_H
