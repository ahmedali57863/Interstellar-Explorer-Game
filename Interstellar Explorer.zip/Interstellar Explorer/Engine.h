#pragma once
#ifndef ENGINE_H
#define ENGINE_H

#include "SDL.h"
#include "SDL_image.h"
#include "GameMap.h"

#define SCREEN_WIDTH 960
#define SCREEN_HEIGHT 640

using namespace std;

class Engine 
{

private:
    Engine() {}
    bool m_IsRunning;

    GameMap* m_LevelMap;
    SDL_Window* m_Window;
    SDL_Renderer* m_Renderer;
    static Engine* s_Instance;

public:
    static Engine* GetInstance() 
    {
        if (s_Instance != nullptr)
        {
            return s_Instance;
        }
        else 
        {
            s_Instance = new Engine();
            return s_Instance;
        }
    }


    bool Init();
    bool Clean();
    void Quit();

    void Update();
    void Render();
    void Events();

    inline GameMap* Getmap() { return m_LevelMap; }
    inline bool IsRunning() { return m_IsRunning; }
    inline SDL_Renderer* GetRenderer() { return m_Renderer; }

};

#endif // ENGINE_H

