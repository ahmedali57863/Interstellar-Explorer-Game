#pragma once
#ifndef TILELAYER_H
#define TILELAYER_H

#include <string>
#include <vector>
#include "Layer.h"
#include "Vector2D.h"

using namespace std;

struct Tileset
{
    int FirstID, LastID;
    int RowCount, ColCount;
    int TileCount, TileSize;
    string Name, Source;
};

using TilesetsList = vector<Tileset>;
using TileMap = vector<vector<int> >;

class TileLayer : public Layer 
{
private:
    int m_TileSize;
    int m_ColCount, m_RowCount;

    TileMap m_Tilemap;
    TilesetsList m_Tilesets;

public:
    TileLayer(int tilesize, int width, int height, TileMap tilemap, TilesetsList tilesets);

    virtual void Render();
    virtual void Update();
    inline TileMap GetTileMap() { return m_Tilemap; }
};

#endif // TILELAYER_H
