#pragma once
#ifndef GAMEMAP_H
#define GAMEMAP_H

#include <vector>
#include "Layer.h"
using namespace std;

class GameMap 
{

private:
    friend class MapParser;
    vector<Layer*> m_MapLayers;

public:
    GameMap() {}

    void Render() 
    {
        for (unsigned int i = 0; i < m_MapLayers.size(); i++)
            m_MapLayers[i]->Render();
    }

    void Update() {
        for (unsigned int i = 0; i < m_MapLayers.size(); i++)
            m_MapLayers[i]->Update();
    }

    std::vector<Layer*> GetLayers() 
    {
        return m_MapLayers;
    }
};

#endif // GAMEMAP_H
